import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import {
    BuildingStorefrontIcon,
    PhotoIcon,
    InformationCircleIcon,
    ChevronDownIcon,
    UserIcon,
    BuildingOfficeIcon,
    TruckIcon,
    UsersIcon,
    ExclamationCircleIcon,
    CheckCircleIcon
} from '@heroicons/react/24/outline';
import OnboardingLayout from '../../components/OnboardingLayout';
import { useOnboardingState } from '../../hooks/useOnboardingState';
import api from '../../utils/api';

const StoreBasicInfo = () => {
    const { t, i18n } = useTranslation();
    const loc = (en, mm) => i18n.language === 'my' ? (mm || en) : (en || mm);
    const navigate = useNavigate();
    const { formData, saveStep, isLoading, businessTypeInfo } = useOnboardingState();
    const [businessTypes, setBusinessTypes] = useState([]);
    const [storeLogoPreview, setStoreLogoPreview] = useState('');
    const [storeBannerPreview, setStoreBannerPreview] = useState('');
    const [uploadingLogo, setUploadingLogo] = useState(false);
    const [uploadingBanner, setUploadingBanner] = useState(false);
    const [error, setError] = useState('');
    const [logoPath, setLogoPath] = useState('');
    const [bannerPath, setBannerPath] = useState('');
    const [logoUploaded, setLogoUploaded] = useState(false);
    const [bannerUploaded, setBannerUploaded] = useState(false);

    const {
        register,
        handleSubmit,
        formState: { errors },
        setValue,
        watch,
        trigger,
        reset,
    } = useForm({
        defaultValues: {
            store_name: '',
            business_type_slug: '',
            contact_email: '',
            contact_phone: '',
            store_description: '',
        }
    });
    useEffect(() => {
        if (!formData.store_basic) return;
        const saved = formData.store_basic;
        const isDefaultStore = saved.store_name?.endsWith("'s Store");
        reset({
            store_name: isDefaultStore ? '' : (saved.store_name || ''),
            business_type_slug: saved.business_type_slug === 'individual' && isDefaultStore
                ? ''
                : (saved.business_type_slug || ''),
            contact_email:     saved.contact_email || '',
            contact_phone:     saved.contact_phone || '',
            description:       saved.store_description || saved.description || '',
        });
        if (saved.store_logo) {
            setStoreLogoPreview(saved.store_logo);
            setLogoPath(saved.store_logo);
            setLogoUploaded(true);
        }
        if (saved.store_banner) {
            setStoreBannerPreview(saved.store_banner);
            setBannerPath(saved.store_banner);
            setBannerUploaded(true);
        }
    }, [formData.store_basic, reset]);

    useEffect(() => {
        fetchBusinessTypes();
    }, []);

    const selectedBusinessSlug = watch('business_type_slug');
    const selectedBusinessType = businessTypes.find(
        bt => bt.slug_en === selectedBusinessSlug || bt.slug === selectedBusinessSlug
    );

    const fetchBusinessTypes = async () => {
        try {
            const response = await api.get('/business-types');
            if (response.data.success) {
                setBusinessTypes(response.data.data);
            }
        } catch (error) {
            console.error('Failed to fetch business types:', error);
            setError('Failed to load business types');
        }
    };

    const getBusinessTypeIcon = (iconName) => {
        const icons = {
            'user': <UserIcon className="h-5 w-5" />,
            'building': <BuildingOfficeIcon className="h-5 w-5" />,
            'store': <BuildingOfficeIcon className="h-5 w-5" />,
            'truck': <TruckIcon className="h-5 w-5" />,
            'users': <UsersIcon className="h-5 w-5" />,
            'default': <BuildingOfficeIcon className="h-5 w-5" />
        };
        return icons[iconName] || icons.default;
    };

    const handleLogoUpload = async (file) => {
        if (!file) return;

        setUploadingLogo(true);
        setError('');

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await api.post('/seller/onboarding/storeLogo', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            if (response.data.success) {
                const { url, path } = response.data.data;
                setStoreLogoPreview(url);
                setLogoPath(path);
                setLogoUploaded(true);
                setValue('store_logo', path, { shouldValidate: true });
                return path;
            } else {
                setError(response.data.message || t('store_basic.upload_logo_failed'));
            }
        } catch (error) {
            const errorMsg = error.response?.data?.message || error.message || t('store_basic.upload_logo_failed');
            setError(errorMsg);
            console.error('Logo upload error:', error);
        } finally {
            setUploadingLogo(false);
        }
    };

    const handleBannerUpload = async (file) => {
        if (!file) return;

        setUploadingBanner(true);
        setError('');

        const formData = new FormData();
        formData.append('image', file);

        try {
            const response = await api.post('/seller/onboarding/storeBanner', formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

                if (response.data.success) {
                const { url, path } = response.data.data;
                setStoreBannerPreview(url);
                setBannerPath(path);
                setBannerUploaded(true);
                setValue('store_banner', path, { shouldValidate: true });
                return path;
            } else {
                setError(response.data.message || t('store_basic.upload_banner_failed'));
            }
        } catch (error) {
            const errorMsg = error.response?.data?.message || error.message || t('store_basic.upload_banner_failed');
            setError(errorMsg);
            console.error('Banner upload error:', error);
        } finally {
            setUploadingBanner(false);
        }
    };

    const handleRemoveLogo = () => {
        setStoreLogoPreview('');
        setLogoPath('');
        setLogoUploaded(false);
        setValue('store_logo', '', { shouldValidate: true });
    };

    const handleRemoveBanner = () => {
        setStoreBannerPreview('');
        setBannerPath('');
        setBannerUploaded(false);
        setValue('store_banner', '', { shouldValidate: true });
    };

    const onSubmit = async (data) => {
        setError('');

        if (!data.store_name?.trim()) {
            setError(t('store_basic.error_store_name'));
            return;
        }

        if (!data.business_type_slug) {
            setError(t('store_basic.error_business_type'));
            return;
        }

        if (!data.contact_email?.trim()) {
            setError(t('store_basic.error_email'));
            return;
        }

        if (!data.contact_phone?.trim()) {
            setError(t('store_basic.error_phone'));
            return;
        }

        const submitData = {
            ...data,
            store_logo:   logoPath,
            store_banner: bannerPath,
        };

        const result = await saveStep('store-basic', submitData);

        if (result.success) {
            const nextStep = result.nextStep || 'business-details';
            navigate(`/seller/onboarding/${nextStep}`);
        } else {
            if (result.errors) {
                const errorMessages = Object.values(result.errors).flat().join(', ');
                setError(errorMessages);
            } else {
                setError(result.message || 'Failed to save store information');
            }
        }
    };

    const handleContinue = async () => {
        const isValid = await trigger();
        if (isValid) {
            const formValues = watch();
            await onSubmit(formValues);
        } else {
            const firstError = Object.keys(errors)[0];
            if (firstError) {
                const element = document.getElementsByName(firstError)[0];
                if (element) {
                    element.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    element.focus();
                }
            }
        }
    };

    return (
        <OnboardingLayout
            title={t("store_basic.title")}
            description={t("store_basic.description")}
            onBack={() => navigate('/seller')}
            onNext={handleContinue}
            nextLabel={t("store_basic.continue_business")}
            nextDisabled={isLoading || uploadingLogo || uploadingBanner}
            loading={isLoading}
        >
            <form onSubmit={handleSubmit(onSubmit)} className="p-6">
                {error && (
                    <div className="mb-6 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl p-4">
                        <div className="flex items-center">
                            <ExclamationCircleIcon className="h-5 w-5 text-red-500 mr-2" />
                            <p className="text-red-700 dark:text-red-400">{error}</p>
                        </div>
                    </div>
                )}

                <div className="space-y-6">
                    {/* Store Media Uploads */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        {/* Logo Upload */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                                {t("store_basic.store_logo")} {!logoUploaded && '*'}
                            </label>
                            <div className="space-y-3">
                                <div className="relative">
                                    <div className={`w-32 h-32 rounded-2xl border-2 ${logoUploaded ? 'border-green-300 dark:border-green-700' : 'border-dashed border-gray-300 dark:border-gray-600'} flex items-center justify-center ${logoUploaded ? 'bg-green-50 dark:bg-green-900/20' : 'bg-gray-50 dark:bg-gray-700'} overflow-hidden mx-auto`}>
                                        {storeLogoPreview ? (
                                            <>
                                                <img
                                                    src={storeLogoPreview}
                                                    alt="Store logo preview"
                                                    className="w-full h-full object-cover"
                                                />
                                                {logoUploaded && (
                                                    <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1">
                                                        <CheckCircleIcon className="h-4 w-4 text-white" />
                                                    </div>
                                                )}
                                            </>
                                        ) : (
                                            <BuildingStorefrontIcon className="h-8 w-8 text-gray-400 dark:text-gray-500" />
                                        )}
                                    </div>
                                </div>
                                <div className="flex flex-col space-y-2">
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleLogoUpload(e.target.files[0])}
                                        className="hidden"
                                        id="logo-upload"
                                        disabled={uploadingLogo}
                                    />
                                    <div className="flex flex-col sm:flex-row gap-2">
                                        <label
                                            htmlFor="logo-upload"
                                            className={`flex-1 text-center px-4 py-2 border rounded-lg cursor-pointer transition-colors ${
                                                uploadingLogo
                                                    ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-400'
                                                    : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                                            }`}
                                        >
                                            {uploadingLogo ? t("store_basic.uploading") : t("store_basic.upload_logo")}
                                        </label>
                                        {logoUploaded && (
                                            <button
                                                type="button"
                                                onClick={handleRemoveLogo}
                                                className="px-4 py-2 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                                            >
                                                {t("store_basic.remove")}
                                            </button>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                                        {t("store_basic.logo_recommended")}
                                    </p>
                                </div>
                            </div>
                        </div>

                        {/* Banner Upload */}
                        <div>
                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                                {t("store_basic.store_banner")}
                            </label>
                            <div className="space-y-3">
                                <div className="relative">
                                    <div className={`w-full h-32 rounded-2xl border-2 ${bannerUploaded ? 'border-green-300 dark:border-green-700' : 'border-dashed border-gray-300 dark:border-gray-600'} flex items-center justify-center ${bannerUploaded ? 'bg-green-50 dark:bg-green-900/20' : 'bg-gray-50 dark:bg-gray-700'} overflow-hidden`}>
                                        {storeBannerPreview ? (
                                            <>
                                                <img
                                                    src={storeBannerPreview}
                                                    alt="Store banner preview"
                                                    className="w-full h-full object-cover"
                                                />
                                                {bannerUploaded && (
                                                    <div className="absolute top-2 right-2 bg-green-500 rounded-full p-1">
                                                        <CheckCircleIcon className="h-4 w-4 text-white" />
                                                    </div>
                                                )}
                                            </>
                                        ) : (
                                            <PhotoIcon className="h-8 w-8 text-gray-400 dark:text-gray-500" />
                                        )}
                                    </div>
                                </div>
                                <div className="flex flex-col space-y-2">
                                    <input
                                        type="file"
                                        accept="image/*"
                                        onChange={(e) => handleBannerUpload(e.target.files[0])}
                                        className="hidden"
                                        id="banner-upload"
                                        disabled={uploadingBanner}
                                    />
                                    <div className="flex flex-col sm:flex-row gap-2">
                                        <label
                                            htmlFor="banner-upload"
                                            className={`flex-1 text-center px-4 py-2 border rounded-lg cursor-pointer transition-colors ${
                                                uploadingBanner
                                                    ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-700 text-blue-700 dark:text-blue-400'
                                                    : 'border-gray-300 dark:border-gray-600 hover:bg-gray-50 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                                            }`}
                                        >
                                            {uploadingBanner ? t("store_basic.uploading") : t("store_basic.upload_banner")}
                                        </label>
                                        {bannerUploaded && (
                                            <button
                                                type="button"
                                                onClick={handleRemoveBanner}
                                                className="px-4 py-2 border border-red-300 dark:border-red-700 text-red-700 dark:text-red-400 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                                            >
                                                {t("store_basic.remove")}
                                            </button>
                                        )}
                                    </div>
                                    <p className="text-xs text-gray-500 dark:text-gray-400 text-center">
                                        {t("store_basic.banner_recommended")}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    {/* Hidden fields for logo/banner URLs */}
                    <input type="hidden" {...register('store_logo')} />
                    <input type="hidden" {...register('store_banner')} />

                    {/* Store Name */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {t("store_basic.store_name")} *
                        </label>
                        <input
                            type="text"
                            name="store_name"
                            className={`mt-1 block w-full px-4 py-3 border ${
                                errors.store_name ? "border-red-300 dark:border-red-600" : "border-gray-300 dark:border-gray-600"
                            } rounded-xl shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500`}
                            placeholder={t("store_basic.enter_store_name")}
                            {...register("store_name", {
                                    required: t('store_basic.store_name_required'),
                                    minLength: {
                                        value: 2,
                                        message: t('store_basic.store_name_min')
                                    }
                                })}
                        />
                        {errors.store_name && (
                            <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.store_name.message}</p>
                        )}
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                            {t("store_basic.store_name_hint")}
                        </p>
                    </div>

                    {/* Business Type */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {t("store_basic.business_type")} *
                        </label>
                        <div className="mt-1 relative">
                            <select
                                name="business_type_slug"
                                className={`block w-full px-4 py-3 border ${
                                    errors.business_type_slug ? "border-red-300 dark:border-red-600" : "border-gray-300 dark:border-gray-600"
                                } rounded-xl shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500 appearance-none`}
                                {...register("business_type_slug", {
                                    required: t('store_basic.business_type_required')
                                })}
                            >
                                <option value="">{t("store_basic.select_business_type")}</option>
                                {businessTypes.map((type) => (
                                    <option key={type.slug_en} value={type.slug_en}>
                                        {loc(type.name_en, type.name_mm)}
                                    </option>
                                ))}
                            </select>
                            <div className="absolute inset-y-0 right-0 flex items-center px-2 pointer-events-none">
                                <ChevronDownIcon className="h-5 w-5 text-gray-400 dark:text-gray-500" />
                            </div>
                        </div>
                        {errors.business_type_slug && (
                            <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.business_type_slug.message}</p>
                        )}
                    </div>

                    {/* Contact Email */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {t("store_basic.contact_email")} *
                        </label>
                        <input
                            type="email"
                            name="contact_email"
                            className={`mt-1 block w-full px-4 py-3 border ${
                                errors.contact_email ? "border-red-300 dark:border-red-600" : "border-gray-300 dark:border-gray-600"
                            } rounded-xl shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500`}
                            placeholder="contact@yourstore.com"
                            {...register("contact_email", {
                                required: t('store_basic.email_required'),
                                pattern: {
                                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                                    message: t('store_basic.invalid_email')
                                }
                            })}
                        />
                        {errors.contact_email && (
                            <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.contact_email.message}</p>
                        )}
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                            {t("store_basic.email_hint")}
                        </p>
                    </div>

                    {/* Contact Phone */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {t("store_basic.contact_phone")} *
                        </label>
                        <input
                            type="tel"
                            name="contact_phone"
                            className={`mt-1 block w-full px-4 py-3 border ${
                                errors.contact_phone ? "border-red-300 dark:border-red-600" : "border-gray-300 dark:border-gray-600"
                            } rounded-xl shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500`}
                            placeholder="+95 123 456 789"
                            {...register("contact_phone", {
                                required: t('store_basic.phone_required'),
                                pattern: {
                                    value: /^\+?[0-9\s\-\(\)]+$/,
                                    message: t('store_basic.invalid_phone')
                                }
                            })}
                        />
                        {errors.contact_phone && (
                            <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.contact_phone.message}</p>
                        )}
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                            {t("store_basic.phone_hint")}
                        </p>
                    </div>

                    {/* Store Description */}
                    <div>
                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300">
                            {t("store_basic.store_description")}
                        </label>
                        <textarea
                            rows={3}
                            name="store_description"
                            className="mt-1 block w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-xl shadow-sm bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 placeholder-gray-400 dark:placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                            placeholder={t("store_basic.description_placeholder")}
                            {...register("store_description", {
                                maxLength: {
                                    value: 2000,
                                    message: t('store_basic.description_limit')
                                }
                            })}
                        />
                        {errors.description && (
                            <p className="mt-1 text-sm text-red-600 dark:text-red-400">{errors.description.message}</p>
                        )}
                        <p className="mt-1 text-xs text-gray-500 dark:text-gray-400">
                            {t("store_basic.description_hint")}
                        </p>
                    </div>
                </div>

                {/* Business Type Info */}
                {selectedBusinessType && (
                    <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-xl border border-blue-200 dark:border-blue-800">
                        <div className="flex items-start">
                            <div className="p-2 rounded-lg bg-blue-100 dark:bg-blue-800/40 mr-3">
                                {getBusinessTypeIcon(selectedBusinessType.icon)}
                            </div>
                            <div className="flex-1">
                                <h4 className="font-medium text-blue-900 dark:text-blue-200">{loc(selectedBusinessType.name_en, selectedBusinessType.name_mm)}</h4>
                                <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">{loc(selectedBusinessType.description_en, selectedBusinessType.description_mm)}</p>
                                <div className="mt-3">
                                    <p className="text-xs font-medium text-blue-800 dark:text-blue-300">{t("store_basic.document_requirements")}:</p>
                                    <ul className="mt-1 text-xs text-blue-700 dark:text-blue-400 space-y-1">
                                        {selectedBusinessType.document_requirements?.map((req, index) => (
                                            <li key={index} className="flex items-start">
                                                <span className="mr-2">•</span>
                                                <span>{req.label} {req.required ? `(${t("store_basic.required")})` : `(${t("store_basic.optional")})`}</span>
                                            </li>
                                        )) || (
                                            <li className="text-blue-600 dark:text-blue-400">{t("store_basic.no_documents")}</li>
                                        )}
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Form Status */}
                <div className="mt-6 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl border border-gray-200 dark:border-gray-600">
                    <div className="flex items-center justify-between">
                        <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-gray-100">{t("store_basic.form_status")}</p>
                            <div className="flex items-center space-x-4 mt-2">
                                <div className="flex items-center">
                                    <div className={`w-3 h-3 rounded-full mr-2 ${logoUploaded ? 'bg-green-500' : 'bg-yellow-500'}`}></div>
                                    <span className="text-xs text-gray-600 dark:text-gray-400">Logo: {logoUploaded ? t("store_basic.logo_uploaded") : t("store_basic.logo_required")}</span>
                                </div>
                                <div className="flex items-center">
                                    <div className={`w-3 h-3 rounded-full mr-2 ${bannerUploaded ? 'bg-green-500' : 'bg-gray-300 dark:bg-gray-500'}`}></div>
                                    <span className="text-xs text-gray-600 dark:text-gray-400">Banner: {bannerUploaded ? t("store_basic.banner_uploaded") : t("store_basic.banner_optional")}</span>
                                </div>
                            </div>
                        </div>
                        <div className="text-right">
                            <p className="text-xs text-gray-500 dark:text-gray-400">{t("store_basic.required_mark")}</p>
                        </div>
                    </div>
                </div>
            </form>
        </OnboardingLayout>
    );
};

export default StoreBasicInfo;
