// pages/categories/CategoryCreate.js
import React from "react";
import CategoryForm from "./CategoryForm";

const CategoryCreate = () => {
  return <CategoryForm />;
};

export default CategoryCreate;
